Instructions
	There is no negative marking for incorrect answers or ommitted questions.
	You can access any learning resources while answering.
	A sample (5-10 rows) of each dataset is shared with you to enhance your comfort with original datasets.
	Your codes will be available to the interviewers. Apart from arriving at the answer, you can use this round as an opportunity to demonstrate your coding taste / preferences.

Glossary
	airline refers to the company operating the planes (like SpiceJet or Indigo airlines).
	plane refers to the model of the machine carrying the passengers.
		Like Boeing-737 or Airbus-200.
		Analogously, Hyundai-I10 or Maruthi Swift in car manufacturing industry.
	flight refers to the trip from airport A to airport B.
	date refers to complete calendar date (like 2018-12-25), while day refers to the component 25 in 2018-12-25.
	month refers to the component 12 in 2018-12-25, and not 2018-12.

Data Dictionary and Description
	flights - Each row corresponds to a flight trip. There is no primary key like flight_id.
		year: 				year component of flight date
		month: 				month component of flight date
		day: 				date component of flight date
		plane_id: 			Identifier of the plane model used for the flight-trip
		scheduled_departure_time_HHMM: 	Time at which the flight was scheduled/planned to take-off (in HHMM format)
						HHMM of 2030 pertains to 08:30 PM
						HHMM of  730 pertains to 07:30 AM
		actual_departure_time_HHMM: 	Time at which the flight actually took-off (in HHMM format)
		scheduled_arrival_time_HHMM: 	Time at which the flight was scheduled/planned to land (in HHMM format)
		actual_arrival_time_HHMM: 	Time at which the flight actually landed (in HHMM format)
		airline_id: 			Identifier of the airline owning the plane used for the flight-trip
		origin_airport: 		Origin Airport
		destination_airport: 		Destination Airport
		distance: 			Distance of the trip
		pilot_id: Pilot identifier. 	Each pilot has 1 pilot ID
		pilot_first_name: 		First name of the pilot
		pilot_last_name: 		Last name of the pilot

	planes - plane_id is primary key. Plane attribute for mapping
		plane_id: 			Identifier of a plane 
		plane_type: 			Plane Type
		plane_model: 			Plane Model 
		manufacturer: 			Company that manufactured the plane
		year_manufactured: 		Year in which the plane was manufactured
		engines_count: 			Count of engines in that plane
		seats_count: 			Count of seats in that plane
		engine_type: 			Type of engine the plane uses
		weight_tonnes: 			Weight of the plane

	airlines - Airline ID to Airline name mapping
		airline_id: 			Airline ID
		airline_name: 			Airline name
		revenue_2000: 			Revenue earned by the airline in 2000
		revenue_2001: 			Revenue earned by the airline in 2001
		revenue_2002: 			Revenue earned by the airline in 2002